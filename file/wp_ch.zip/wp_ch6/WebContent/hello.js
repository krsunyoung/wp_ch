	document.write("<h1>Hello JavaScript</h1>");
	console.log("Hello World");
	console.error("Hello World");
	console.info("Hello World");
	console.debug("Hello World");
	
	//alert("Hello World"); //창을 띄우기도 하지만 잠시 멈추기도 해서 많이 쓰이지 않는다. 디버깅 하기 않좋음.